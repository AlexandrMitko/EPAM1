/*let maximumNumberOfLoginAttempts = 10
var currentLoginAttempt = 0

 var FriendlyWe = "Hello"
FriendlyWe = "Bonjour"

print(FriendlyWe)
print("The current v of fw is \(FriendlyWe)")

let t = 3
let p = 0.14159
let pi =  Double(t) + (p)
let iPi = Int(pi)

typealias AudioSample = UInt
var max = AudioSample.max

let orangesAreO = true
let chocolatesAreTasty = false

if chocolatesAreTasty {
    print ("MMm")
} else {
    print("Eww, chocolates are horrible")
}

let i = 1
if i == 1 {
    
}

let errot =  (404, "Not Found")
let (sC, sM) = error
print ("The status code is \(sC)")

let b = 10
var a = 5
a = b
a == b
print(a+b)

7%4

9 == (4*2)+1

(3, "mom") < (3, "t")

for index in 1...5 {
    print("\(index) times 5 is \(index*5)")
}

let names = ["Anna", "Sasha", "Vitya", "Masha"]
let count = names.count
for  i in 0..<count {
    print("Person \(i+1) is called \(names[i])")
}

let threeDoubleQuotes = """
Escaping the first quote \"""
Escaping all three quotes \"""

"""

let seeSomeMiracle = """
One
            Two
Three
"""

var eS = "Three"
if eS.isEmpty {
    print ("Dude, why you did not typed anything?") }
else {
        print("Well done, mate!")
        
    }

var myString = "What"
myString += " is wrong with this world?"

for c in "Smile!" {
    print(c)
}

let seeSmth: [Character] = ["B", "o", "y", "!"]
var k = String(seeSmth)
print(k)
let exclamationMark: Character = "!"
k.append(exclamationMark)

var word = "cafe"
print("The number of characters in a \(word) is \(word.count)")
word += "\u{301}"
print("The number of characters in a \(word) is \(word.count)")

var welcome = "hello"
welcome.insert("!", at: welcome.endIndex)
welcome.insert (contentsOf: " there", at: welcome.index(before: welcome.endIndex))


func greet(person: String) -> String {
    let greeting = "Hello, " + person + "!"
    return greeting
   
}
 print(greet(person: "Anna"))



func printAndCount(string: String) -> Int {
    print(string)
    return string.characters.count
}
func printWithoutCounting(string: String) {
    let _ = printAndCount(string: string)
}
printAndCount(string: "hello, world")

printWithoutCounting(string: "hello, world")


func minMax(array: [Int]) -> (min: Int, max: Int) {
var currentMin = array[0]
var currentMax = array[0]
for value in array[1..<array.count] {
if value < currentMin {
currentMin = value
}
else if value > currentMax {
currentMax = value

}

}
return (currentMin, currentMax)
}
let bounds = minMax(array: [8, 12, -2, 23, 42, 2, -55])
print("min is \(bounds.min) and max is \(bounds.max)")

func swapTwoInts (_ a: inout Int, _ b: inout Int) {
     let temporaryA = a
    a = b
    b = temporaryA
}

var a = 3
var b = 107
swapTwoInts(&a, &b)
print("someInt now is \(a) and anotherInt now is \(b)")


func addTwoInts (a: Int, _ b: Int) -> Int {
    return a+b
}
func multiplyTwoInts(a: Int, _ b: Int) -> Int {
    return a * b
}

var math: (Int, Int) -> Int = addTwoInts
var mathe: (Int, Int) -> Int = multiplyTwoInts
print("Resault: \(math(2,3)) and \(mathe(2,8))")


enum Optional<T> {
    case none
    case some(T)
}
*************
let x: String? = nil
...is!!!
let x = Optional<String>.none

let x: String? = "hello"
...is!!!
let x = Optional<String>.some("hello")

*************
let y = x!
...is!!!
switch x {
case some(let value): y = value
case none:
    
}
*************

let x: String? = ...
if let y = x {
  do smth w/ y
}
...is!!!

switch x {
case .some(let y):
 // do smth w/ y
  case .none
 break
}
*/

//tuples:
//*************
/*let x: (String, Int, Double) = ("hello", 5, 0.85)
let (word, number, value) = x
print (word)
print(number)
print(value)

*************

let y: (w: String, i: Int, v: Double) = ("hello", 5, 0.85)
print(y.w)
print(y.i)
print(y.v)
*/
//*************
/*func getSize() -> (weight: Double, height: Double) {return (250, 80)}

let x = getSize()
print("weight is \(x.weight)")
print("height is \(getSize().height)")
*/

//range
//*******
/*for i in 0..<20 {
    
}

*************
for double/float
for i in stride (from: 0.5, through: 15.25, by: 0.3) {

}

*/

//Sruct + Classes + Enums


/*Чем похожи:
1) Объявления*/

/*clas ViewController: ... {
    
}

struct CalcMind {
    
}

enum Op {
    
}*/
/* 2) Все могут иметь свойства + функции */

/* func doit(argx argi: Type) -> ReturnValue {
    
}

var storedProperty = <initial value> (not enum)

var computedProperty: Type {
    get {}
    set {}
}

*/
/* 3) Классы и структура имееют инициализаторы */

/*init(arglx arli: Type, arg2x arg2i: Type, ...) {
    
}*/

//Различия
/* 1) Наследование (только классы)
 2) Тип значения (Value Type) (только структуры и перечисления)
 3) Ссылочный тип (только классы)
 
 */

/*Value Type (struct and enum)
 Copied when passed as an argument to a function
 Copied when assigned to a different variable
 Immutable if assigned to a variable with let (func params are let)
 You must note any func that can mutate a struct/enum with the keyword mutating
*/

/* Ссылки в классах
 Считаются автоматически
 let  может быть модифицирован если вызвать метод и изменить свойства
 Когда посылается в качествае аргумента -- не делает копию (как это делается в структурах и перечислениях)!!!
 */

// Методы!!!
/*
 func foo (_ first: Int, externalSecond second: Double) {
 var sum = 0.0
 for _ in 0..<first { sum += second }
 }
 
 func bar () {
 let result = foo (123, externalSecond: 5.5)
 }

 */
//*********
/*
static func abs(d: Double) -> Double { if d < 0 {return -d} else {return d}}
static var pi: Double {return 3.1415926}

let d = Double.pi
let d = Double.abs(-324.44)

*/

/* МАССИВЫ!!!!*/


 var a = [String]()
 
 let animals = ["Dog", "Cat", "Mouse", "Lion"]
 
 for animal in animals {
 print (animal)
 }



